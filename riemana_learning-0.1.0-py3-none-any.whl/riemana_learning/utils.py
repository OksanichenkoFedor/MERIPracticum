import numpy as np

def smooth(A, window_size):
    B = np.zeros(A.shape)
    for i in range(len(A)):
        if i < window_size // 2:
            B[i] = np.mean(A[:2 * i + 1])
        elif i > len(A) - window_size // 2 - 1:
            B[i] = np.mean(A[len(A) - 2 * (len(A) - i - 1) - 1:])
        else:
            B[i] = np.mean(A[i - window_size // 2:i + window_size // 2 + 1])
    return B
