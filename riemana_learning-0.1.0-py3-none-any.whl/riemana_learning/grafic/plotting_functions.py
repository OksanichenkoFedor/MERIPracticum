import numpy as np
from matplotlib import pyplot as plt


def plot_prepared_profile(axis, X, Y, point=None, angle=None, label=None):
    axis.set_aspect(1)
    axis.plot(X, Y, label=label)
    #axis.plot(X, Y, ".")
    if not (point is None):
        axis.plot([point[0]], [point[1]], "o",color="r")
    ylim = axis.get_ylim()

    if not (angle is None):
        r_max = np.sqrt((X[-1]-point[0])**2+(Y[-1]-point[1])**2)
        r = np.linspace(0,r_max,1000)
        x = np.sin(angle)*r+point[0]
        y = np.cos(angle)*r+point[1]
        axis.plot(x,y,color="r")
    axis.set_ylim([ylim[1] + 1, ylim[0] - 1])
    x_ticks_major = axis.get_xticks()
    x_ticks_minor = np.linspace(x_ticks_major[0], x_ticks_major[-1], len(x_ticks_major) * 2 - 1)
    axis.set_xticks(x_ticks_minor)
    axis.grid()

    if not (label is None):
        axis.legend()

def plot_in_radial_coords(axis, X, Y):
    axis.plot(X, Y)
    #print((Y[-1]-Y[-2])/(X[-1]-X[-2]))
    axis.grid()