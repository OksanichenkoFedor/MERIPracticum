from importlib.metadata import version
__version__ = version("riemana_learning")

from riemana_learning.models.profile_predictor import ProfilePredictor