from abc import ABC, abstractmethod
import numpy as np


class Mapper(ABC):
    def __init__(self):
        self.is_load = False

    def load(self, max_angle):
        self.is_load = True
        self.max_angle = max_angle
        self.prepare()

    @abstractmethod
    def prepare(self):
        pass

    @abstractmethod
    def forward(self, array):
        pass

    @abstractmethod
    def backward(self, array):
        pass

    @abstractmethod
    def derivative(self, phi):
        pass

class LinearMapper(Mapper):
    def prepare(self):
        pass

    def forward(self, array):
        if self.is_load==False:
            raise Exception("Unloaded Mapper")
        return (array+np.pi*0.5)/(self.max_angle+np.pi*0.5)

    def backward(self, array):
        if self.is_load==False:
            raise Exception("Unloaded Mapper")
        return array*((self.max_angle+np.pi*0.5))-0.5*np.pi

    def derivative(self, phi):
        # d(phi)/d(psi)
        return 1/(self.max_angle+np.pi*0.5)

class QuarterMapper(Mapper):
    def prepare(self):
        self.k = 0.75/self.max_angle
        self.alpha = find_alpha(self.k)
        self.beta = np.log(self.k/self.alpha)
        self.gamma = np.exp(self.beta)-0.25

    def forward(self, array):
        if self.is_load==False:
            raise Exception("Unloaded Mapper")
        res_array = np.zeros(len(array))
        for i in range(len(array)):
            if array[i] < 0:
                res_array[i] = np.exp(self.alpha*array[i]+self.beta)-self.gamma
            else:
                res_array[i] = array[i]*self.k + 0.25
        return res_array

    def backward(self, array):
        if self.is_load==False:
            raise Exception("Unloaded Mapper")
        res_array = np.zeros(array.shape)
        for i in range(len(array)):
            if array[i]<0.25:
                res_array[i] = (np.log(array[i]+self.gamma)-self.beta)/self.alpha
            else:
                res_array[i] = array[i]/self.k - 0.25/self.k
        return res_array

    def derivative(self, phi):
        # d(psi)/d(phi)
        if phi>0:
            return self.k
        else:
            return np.exp(self.alpha*phi+self.beta)*self.alpha



def find_alpha(k):
    left = 1.0
    while 0.25*left>k*(1-np.exp(-left*0.5*np.pi)):
        left*=0.5
    right = 1.0
    while 0.25*right<k*(1-np.exp((-1.0)*right*0.5*np.pi)):
        right*=2.0
    while np.abs(left-right)/(left+right)>10.0**(-10.0):
        curr = 0.5*(left+right)
        if 0.25*curr>k*(1-np.exp(-curr*0.5*np.pi)):
            right = curr
        else:
            left = curr
    return (left+right)*0.5
