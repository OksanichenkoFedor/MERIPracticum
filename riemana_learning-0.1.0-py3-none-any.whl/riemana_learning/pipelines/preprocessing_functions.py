import re
from typing import Optional

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

from riemana_learning.grafic.plotting_functions import plot_prepared_profile, plot_in_radial_coords
from riemana_learning.pipelines.mappers import QuarterMapper
from riemana_learning.pipelines.models import UniformPredictModel
from riemana_learning.pipelines.parametrization_converter import ParametrizationConverter
from riemana_learning.pipelines.poly_param_converter import PolyParametrizationConverter


def get_profile_arrays(dataframe: pd.DataFrame, number: int):
    tmp = dataframe.loc[number]["X"].replace("\n", "").replace(",", "")[1:-1]
    tmp = re.sub(r'\s+', ' ', tmp)[:]
    X = np.array(tmp.split()).astype(float)
    tmp = dataframe.loc[number]["Y"].replace("\n", "").replace(",", "")[1:-1]
    tmp = re.sub(r'\s+', ' ', tmp)[:]
    Y = np.array(tmp.split()).astype(float)
    if X[-1]*2%2!=0:
        X = np.concatenate([X[:-2],(2*X[-1]-X[:-2])[::-1]])
        Y = np.concatenate([Y[:-2],Y[:-2][::-1]])
    return X, Y

def prepare_poly(coords : tuple[int],
             dataframe : pd.DataFrame,
             number: int,
             size_after_preprocessing: int):
    X, Y = get_profile_arrays(dataframe, number)
    param_conv = ParametrizationConverter(coords)
    model_x, model_y = UniformPredictModel(), UniformPredictModel()
    param_conv.load_cartesian(X, Y)
    param_conv.convert_from_cartesian_to_poly(window_size=7, size_after_preprocessing=size_after_preprocessing, model_x=model_x, model_y=model_y)
    return param_conv.get_poly_vector()

def prepare_x(dataframe : pd.DataFrame, number: int):
    #U = dataframe.loc[number]["U"]
    W = dataframe.loc[number]["W"]
    ar = dataframe.loc[number]["ar"]
    T = dataframe.loc[number]["T"]
    #return np.array([U, W, ar, T]).astype(float)
    return np.array([W, ar, T]).astype(float)


def compare_poly_data(coords : tuple[int],
                      dataframe : pd.DataFrame,
                      number: int,
                      size_after_preprocessing: int,
                      bound_part: float,
                      poly_pred: np.ndarray[np.float64],
                      axis: Optional[plt.axis] = None,
                      additional_axis_X: Optional[plt.axis] = None,
                      additional_axis_Y: Optional[plt.axis] = None):
    X, Y = get_profile_arrays(dataframe, number)
    param_conv = ParametrizationConverter(*coords)
    model_x, model_y = UniformPredictModel(), UniformPredictModel()
    param_conv.load_cartesian(X, Y)

    param_conv.convert_from_cartesian_to_poly(window_size=7, size_after_preprocessing=size_after_preprocessing, model_x=model_x, model_y=model_y,
                                              bound_part=bound_part)

    poly_pred_conv = PolyParametrizationConverter(*coords)
    poly_pred_conv.load_poly(poly_pred)
    poly_pred_conv.convert_from_poly_to_cartesian(size_after_preprocessing=size_after_preprocessing, model_x=model_x, model_y=model_y)

    poly_real_conv = PolyParametrizationConverter(*coords)
    poly_real_conv.load_poly(param_conv.get_poly_vector())
    poly_real_conv.convert_from_poly_to_cartesian(size_after_preprocessing=size_after_preprocessing, model_x=model_x, model_y=model_y)

    if axis is None:
        pass
    else:
        plot_prepared_profile(axis, param_conv.get_full_x(), param_conv.get_full_y())
        #plot_prepared_profile(axis, poly_real_conv.get_symmetrical_x(), poly_real_conv.get_symmetrical_y(), label="symmetrical")
        plot_prepared_profile(axis, poly_pred_conv.get_symmetrical_x(), poly_pred_conv.get_symmetrical_y())

    if additional_axis_X is None:
        pass
    else:
        plot_in_radial_coords(additional_axis_X, param_conv.get_t(), param_conv.get_inflected_x())
        plot_in_radial_coords(additional_axis_X, poly_pred_conv.get_t(), poly_pred_conv.get_x())

    if additional_axis_Y is None:
        pass
    else:
        plot_in_radial_coords(additional_axis_Y, param_conv.get_t(), param_conv.get_inflected_y())
        plot_in_radial_coords(additional_axis_Y, poly_pred_conv.get_t(), poly_pred_conv.get_y())


def give_cartesian_from_poly(coords : tuple[int],
                        poly_pred : np.ndarray[np.float64],
                        size_after_preprocessing: int):
    mapper = QuarterMapper()
    model_x, model_y = UniformPredictModel(), UniformPredictModel()
    poly_pred_conv = PolyParametrizationConverter(*coords)
    poly_pred_conv.load_poly(poly_pred)
    poly_pred_conv.convert_from_poly_to_cartesian(size_after_preprocessing=size_after_preprocessing, model_x=model_x, model_y=model_y)
    return poly_pred_conv.get_symmetrical_x(), poly_pred_conv.get_symmetrical_y()