from copy import deepcopy

import numpy as np

from riemana_learning.pipelines.models import PredictingModel
from riemana_learning.pipelines.poly_mapper_converter import PolyConverter


class PolyParametrizationConverter(PolyConverter):

    def convert_from_poly_to_cartesian(self, size_after_preprocessing, model_x, model_y):
        if self.is_load:
            self.count_cartesian_from_poly(size_after_preprocessing, model_x, model_y)
            self.count_symmetrical_cartesian()
            self.is_processed = True
        else:
            raise Exception("Try to process unloaded x,y")

    def count_cartesian_from_poly(self, size_after_preprocessing: int, model_x: PredictingModel,
                                                model_y: PredictingModel):
        self.t = np.linspace(0, 1, 1000)

        self.model_x = model_x
        self.model_x.init(size_after_preprocessing)
        self.x_weights = self.poly_vector[0:size_after_preprocessing]
        self.model_x.load(self.x_weights)
        self.x = self.model_x.predict(self.t)

        self.model_y = model_y
        self.model_y.init(size_after_preprocessing)
        self.y_weights = self.poly_vector[size_after_preprocessing:]
        self.model_y.load(self.y_weights)
        self.y = self.model_y.predict(self.t)


    def get_t(self):
        if self.is_processed:
            return self.t
        else:
            raise Exception("Try to get unprocessed variables")

    def get_x_etch(self):
        if self.is_processed:
            return self.x[0]-self.left
        else:
            raise Exception("Try to get unprocessed variables")

    def get_y_etch(self):
        if self.is_processed:
            return self.y[-1]-self.y[0]
        else:
            raise Exception("Try to get unprocessed variables")