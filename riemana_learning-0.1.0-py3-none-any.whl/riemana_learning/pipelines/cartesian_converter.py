from copy import deepcopy

import numpy as np
from scipy.interpolate import interp1d, CubicSpline
from scipy.optimize import minimize

from riemana_learning.pipelines.mappers import Mapper
from riemana_learning.utils import smooth



class CoordinatesConverter:
    def __init__(self, left, right, down):
        self.left, self.right, self.down = left, right, down
        self.horizontal_gap = max(1, int(0.1*(self.right-self.left)))
        self.is_add_size_of_etching_zone = (self.right-self.left)%2==0
        self.clean()

    def clean(self):
        pass

    def load_cartesian(self, x, y):
        self.pure_x, self.pure_y = x, y
        self.is_load = True

    def prepare_profile(self):
        ind_start = 0
        ind_half_end, ind_full_end = len(self.pure_x) - 1, len(self.pure_x) - 1
        while self.pure_y[ind_start] <= self.down + 1:
            ind_start += 1
        ind_start -= 1

        while self.pure_x[ind_half_end] >= 0.5 * (self.left + self.right):
            ind_half_end -= 1
        ind_half_end += 1

        while self.pure_y[ind_full_end] <= self.down + 1:
            ind_full_end -= 1
        ind_full_end += 2

        self.x = np.array(self.pure_x[ind_start:ind_half_end])
        self.y = np.array(self.pure_y[ind_start:ind_half_end])

        if not self.is_add_size_of_etching_zone:
            self.x = np.append(self.x,self.x[-1]+0.5)
            self.y = np.append(self.y,self.y[-1])

        self.full_x = np.array(self.pure_x[ind_start:ind_full_end])
        self.full_y = np.array(self.pure_y[ind_start:ind_full_end])

    def count_smooth_from_cartesian(self, window_size: int):
        t = np.arange(0, len(self.x), 1)
        t = t / (np.max(t))
        self.t_to_x = CubicSpline(t, smooth(self.x, window_size))
        self.t_to_y = CubicSpline(t, smooth(self.y, window_size))
        self.new_t = np.linspace(0, 1, 100)
        self.smooth_x, self.smooth_y = self.t_to_x(self.new_t), self.t_to_y(self.new_t)

    def count_symmetrical_cartesian(self):
        remind_x, remind_y = self.left+self.right-deepcopy(self.x), deepcopy(self.y)
        self.symmetrical_x = np.concatenate((self.x, remind_x[::-1]), axis=0)
        self.symmetrical_y = np.concatenate((self.y, remind_y[::-1]), axis=0)

    def get_x(self):
        if self.is_processed:
            return self.x
        else:
            raise Exception("Try to get unprocessed variables")

    def get_y(self):
        if self.is_processed:
            return self.y
        else:
            raise Exception("Try to get unprocessed variables")

    def get_smooth_x(self):
        if self.is_processed:
            return self.smooth_x
        else:
            raise Exception("Try to get unprocessed variables")

    def get_smooth_y(self):
        if self.is_processed:
            return self.smooth_y
        else:
            raise Exception("Try to get unprocessed variables")

    def get_poly_vector(self):
        if self.is_processed:
            return self.poly_vector
        else:
            raise Exception("Try to get unprocessed variables")

    def get_full_x(self):
        if self.is_processed:
            return self.full_x
        else:
            raise Exception("Try to get unprocessed variables")

    def get_full_y(self):
        if self.is_processed:
            return self.full_y
        else:
            raise Exception("Try to get unprocessed variables")

    def get_symmetrical_x(self):
        if self.is_processed:
            return self.symmetrical_x
        else:
            raise Exception("Try to get unprocessed variables")

    def get_symmetrical_y(self):
        if self.is_processed:
            return self.symmetrical_y
        else:
            raise Exception("Try to get unprocessed variables")

class CartesianConverter(CoordinatesConverter):

    def clean(self):
        self.is_add_size_of_etching_zone = None
        self.is_load = False
        self.is_processed = False
        self.x, self.y = None, None
        self.smooth_x, self.smooth_y, self.t_to_x, self.t_to_y, self.new_t = [None]*5
        self.x_left, self.y_left = None, None
        self.r, self.phi = [None]*2
        self.phi_uniform, self.r_uniform, self.max_angle = [None]*3
        self.mapper, self.psi = None, None
        self.max_x, self.max_y = None, None
        self.derivatives, self.consts = None, None
        self.model, self.poly_vector = None, None

    def convert_from_cartesian_to_poly(self, window_size, size_after_preprocessing, mapper, model):
        if self.is_load:
            self.prepare_profile()
            self.count_smooth_from_cartesian(window_size=window_size)
            self.count_left_from_smooth()
            self.count_radial_from_left()
            self.count_unirad_from_radial()
            self.count_psi_from_uniphi(mapper)
            self.find_max_point()
            self.create_constaraints()
            self.count_from_psi_r_to_poly(size_after_preprocessing=size_after_preprocessing, model=model)
            self.count_symmetrical_cartesian()
            self.is_processed = True
        else:
            raise Exception("Try to process unloaded x,y")

    def count_left_from_smooth(self):
        #print(self.smooth_x[-1], self.left, self.right)
        self.x_left = self.smooth_x - (self.left+self.horizontal_gap)
        self.y_left = self.smooth_y - (self.down + 1)

    def count_radial_from_left(self):
        self.r = np.sqrt(self.x_left * self.x_left + self.y_left * self.y_left)
        self.phi = np.arctan2(self.x_left, self.y_left)

    def count_unirad_from_radial(self):
        phi, indices = np.unique(self.phi, return_index=True)
        r = self.r[indices]
        interp_func = interp1d(phi, r, kind='cubic')
        self.phi_uniform = np.linspace((-0.5)*np.pi, phi.max(), 1000)
        self.r_uniform = interp_func(self.phi_uniform)
        self.max_angle = self.phi_uniform[-1]

    def count_psi_from_uniphi(self, mapper: Mapper):
        self.mapper = mapper
        self.mapper.load(self.max_angle)
        self.psi = self.mapper.forward(self.phi_uniform)
        self.psi[0], self.psi[-1] = 0.0, 1.0

    def find_max_point(self):
        t_max = self.new_t[self.smooth_y.argmax()]
        res = minimize(lambda t: (-1.0)*self.t_to_y(t[0]),[t_max], bounds=[(0,1)], tol=0.1, method='Nelder-Mead')
        t_max = res.x
        self.max_x, self.max_y = self.t_to_x(t_max), self.t_to_y(t_max)
        delta_x = self.max_x - (self.left+self.horizontal_gap)
        delta_y = self.max_y - (self.down + 1)
        delta_r = np.sqrt(delta_x**2+delta_y**2)
        self.lowest_phi = np.asin(delta_x/delta_r)[0]
        self.lowest_r = delta_r

    def add_extremum(self, phi, r):
        derivative_val = np.sin(phi)*(r / np.sin(np.pi * 0.5 + phi)) * (1.0/self.mapper.derivative(phi))
        derivative_point = self.mapper.forward([phi])[0]
        self.derivatives.append({"point": derivative_point, "value": derivative_val})
        self.consts.append({"point": derivative_point, "value": r})

    def create_constaraints(self):
        self.derivatives = []
        self.consts = []
        #print("---")
        #print("cc: ",self.max_angle, self.x_left[-1],self.r_uniform[-1])
        self.add_extremum(self.max_angle, self.r_uniform[-1])
        #self.add_extremum(self.lowest_phi, self.lowest_r)
        self.consts.append({"point": 0, "value": self.r_uniform[0]})

    def count_from_psi_r_to_poly(self, size_after_preprocessing, model):

        self.model = model
        self.model.init(size_after_preprocessing)
        self.model.fit(self.psi, self.r_uniform, self.derivatives, self.consts)

        self.poly_vector = self.model.get_w()

    def get_psi(self):
        if self.is_processed:
            return self.psi
        else:
            raise Exception("Try to get unprocessed variables")

    def get_r_uniform(self):
        if self.is_processed:
            return self.r_uniform
        else:
            raise Exception("Try to get unprocessed variables")

    def get_max_angle(self):
        if self.is_processed:
            return self.max_angle
        else:
            raise Exception("Try to get unprocessed variables")

    def get_max_point(self):
        if self.is_processed:
            return self.max_x, self.max_y
        else:
            raise Exception("Try to get unprocessed variables")