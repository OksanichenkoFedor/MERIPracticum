import numpy as np
from scipy.interpolate import CubicSpline, PchipInterpolator

from riemana_learning.pipelines.cartesian_converter import CoordinatesConverter


class ParametrizationConverter(CoordinatesConverter):
    def convert_from_cartesian_to_poly(self, window_size, size_after_preprocessing, model_x, model_y, bound_part):
        self.bound_part = bound_part
        if self.is_load:
            self.prepare_profile()
            self.count_smooth_from_cartesian(window_size=window_size)
            self.find_inflection_point()
            self.count_inflected_from_smooth()
            self.count_from_inflected_to_poly(size_after_preprocessing=size_after_preprocessing,
                                              model_x=model_x, model_y=model_y)
            self.count_symmetrical_cartesian()
            self.is_processed = True
        else:
            raise Exception("Try to process unloaded x,y")

    def find_inflection_point(self):
        self.dy = np.gradient(self.smooth_y, self.new_t[1]-self.new_t[0])
        deriv_spline = CubicSpline(self.new_t, self.dy)
        self.zero_t = []
        target_value = 0
        for i in range(len(self.new_t) - 1):
            high = self.new_t[i]
            low = self.new_t[i + 1]
            is_checking = True
            if deriv_spline(low)<=target_value and deriv_spline(high)>=target_value:
                is_checking = True
            curr = None
            real_min = 1
            while (np.abs(high - low) > 1e-5) and is_checking:
                mid = (low + high) / 2
                if deriv_spline(mid) < target_value:
                    low = mid
                else:
                    high = mid
                curr = None
                curr_min = abs(deriv_spline(mid) - target_value)
                if curr_min < 1e-1:
                    if curr is None:
                        curr = mid
                        real_min = curr_min
                    else:
                        if curr_min<real_min:
                            curr = mid
                            real_min = curr_min

            if not (curr is None):
                self.zero_t.append(curr)

        if len(self.zero_t)==0:
            self.zero_t = 0.999
        else:
            self.zero_t = self.zero_t[0]
        self.inflection_x_point, self.inflection_y_point = self.t_to_x(self.zero_t), self.t_to_y(self.zero_t)
        self.inflection_dy = 0

    def count_inflected_from_smooth(self):
        self.repr_spl = give_representation_spline([(self.zero_t, self.bound_part)], 1)
        self.repr_t = self.repr_spl(self.new_t)
        self.repr_t_to_x = CubicSpline(self.repr_t, self.smooth_x)
        self.repr_t_to_y = CubicSpline(self.repr_t, self.smooth_y)
        self.inflected_x = self.repr_t_to_x(self.new_t)
        self.inflected_y = self.repr_t_to_y(self.new_t)

    def count_from_inflected_to_poly(self, size_after_preprocessing, model_x, model_y):
        self.model_x = model_x
        self.model_x.init(size_after_preprocessing)
        self.model_x.fit(self.new_t, self.inflected_x, [], [])

        self.model_y = model_y
        self.model_y.init(size_after_preprocessing)
        self.model_y.fit(self.new_t, self.inflected_y, [], [])


        self.x_poly_vector = self.model_x.get_w()
        self.y_poly_vector = self.model_y.get_w()


    def get_poly_vector(self):
        if self.is_processed:
            return np.concatenate((self.x_poly_vector, self.y_poly_vector), axis=0)
        else:
            raise Exception("Try to get unprocessed variables")

    def get_t(self):
        if self.is_processed:
            return self.new_t
        else:
            raise Exception("Try to get unprocessed variables")

    def get_inflected_x(self):
        if self.is_processed:
            return self.inflected_x
        else:
            raise Exception("Try to get unprocessed variables")

    def get_inflected_y(self):
        if self.is_processed:
            return self.inflected_y
        else:
            raise Exception("Try to get unprocessed variables")


def give_representation_spline(points,n_in):
    x = [0]
    y = [0]
    start_x, start_y = 0, 0
    for x_p, y_p in points:
        add_x = np.linspace(start_x, x_p, n_in+2)[1:]
        add_y = np.linspace(start_y, y_p, n_in+2)[1:]
        x+=list(add_x)
        y+=list(add_y)
        start_x, start_y = x_p, y_p
    add_x = np.linspace(start_x, 1.0, n_in+2)[1:]
    add_y = np.linspace(start_y, 1.0, n_in+2)[1:]
    x+=list(add_x)
    y+=list(add_y)
    cs = PchipInterpolator(x, y)
    return cs