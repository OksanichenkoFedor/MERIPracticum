from copy import deepcopy

import numpy as np

from riemana_learning.pipelines.models import PredictingModel
from riemana_learning.pipelines.mappers import Mapper


class PolyConverter:
    def __init__(self, left, right, down):
        self.left, self.right, self.down = left, right, down
        self.horizontal_gap = max(1, int(0.1 * (self.right - self.left)))
        self.is_add_size_of_etching_zone = (self.right - self.left) % 2 == 0
        self.clean()

    def clean(self):
        pass

    def load_poly(self, poly_vector):
        self.poly_vector = poly_vector
        self.is_load = True

    def count_symmetrical_cartesian(self):
        remind_x, remind_y = self.left+self.right-deepcopy(self.x), deepcopy(self.y)
        self.symmetrical_x = np.concatenate((self.x, remind_x[::-1]), axis=0)
        self.symmetrical_y = np.concatenate((self.y, remind_y[::-1]), axis=0)

    def get_x(self):
        if self.is_processed:
            return self.x
        else:
            raise Exception("Try to get unprocessed variables")

    def get_y(self):
        if self.is_processed:
            return self.y
        else:
            raise Exception("Try to get unprocessed variables")

    def get_symmetrical_x(self):
        if self.is_processed:
            return self.symmetrical_x
        else:
            raise Exception("Try to get unprocessed variables")

    def get_symmetrical_y(self):
        if self.is_processed:
            return self.symmetrical_y
        else:
            raise Exception("Try to get unprocessed variables")



class PolyMapperConverter(PolyConverter):
    def convert_from_poly_to_cartesian(self, size_after_preprocessing, mapper, model):
        if self.is_load:
            self.count_psi_r_from_poly(size_after_preprocessing, model)
            self.count_phi_from_psi(mapper)
            self.count_left_from_radial()
            self.count_cartesian_from_left()
            self.count_symmetrical_cartesian()
            self.is_processed = True
        else:
            raise Exception("Try to process unloaded x,y")

    def count_psi_r_from_poly(self, size_after_preprocessing: int, model: PredictingModel):
        self.model = model
        self.model.init(size_after_preprocessing)
        self.model.load(self.poly_vector)
        self.psi = np.linspace(0, 1, 1000)
        self.r = self.model.predict(self.psi)
        sin = (self.right * 0.5 - self.left * 0.5 - self.horizontal_gap)/self.r[-1]
        self.max_angle = np.asin(sin)


    def count_phi_from_psi(self, mapper: Mapper):
        self.mapper = mapper
        self.mapper.load(self.max_angle)
        self.phi = self.mapper.backward(self.psi)

    def count_left_from_radial(self):
        self.x_left = self.r * np.sin(self.phi)
        self.y_left = self.r * np.cos(self.phi)

    def count_cartesian_from_left(self):
        self.x = self.x_left + (self.left+self.horizontal_gap)
        self.y = self.y_left + (self.down + 1)

    def get_psi(self):
        if self.is_processed:
            return self.psi
        else:
            raise Exception("Try to get unprocessed variables")

    def get_r(self):
        if self.is_processed:
            return self.r
        else:
            raise Exception("Try to get unprocessed variables")