import numpy as np
from scipy.optimize import minimize
from scipy.interpolate import interp1d
from sklearn.preprocessing import PolynomialFeatures
from abc import ABC, abstractmethod

class PredictingModel(ABC):
    def __init__(self):
        self.is_init=False

    @abstractmethod
    def init(self, size):
        pass

    @abstractmethod
    def load(self, weights):
        pass

    @abstractmethod
    def fit(self, X, y, derivatives, consts):
        pass

    @abstractmethod
    def predict(self, X):
        pass

    @abstractmethod
    def generate_derivative_constraint_function(self, derivative):
        pass

    @abstractmethod
    def generate_constant_constraint_function(self, constant):
        pass

    @abstractmethod
    def get_w(self):
        pass




class DerivativeLinearRegression(PredictingModel):

    def init(self, size):
        self.is_init = True
        self.size = size
        self.poly = PolynomialFeatures(size=self.size)
        self.is_fitted = False

    def fit(self, X, y, derivatives, consts, alpha=0.00001):
        if not self.is_init:
            raise Exception("DerivativeLinearRegression is not init")
        self.alpha = alpha
        constraints = []
        for derivative in derivatives:
            new_constraint = {'type': 'eq', 'fun': self.generate_derivative_constraint_function(derivative)}
            constraints.append(new_constraint)
        for const in consts:
            new_constraint = {'type': 'eq', 'fun': self.generate_constant_constraint_function(const)}
            constraints.append(new_constraint)


        X_poly = self.poly.fit_transform(X.reshape(-1, 1))
        w_init = np.zeros(X_poly.shape[1])

        res = minimize(self.custom_loss, w_init, args=(X_poly, y), constraints=constraints)
        self.w = res.x
        self.is_fitted = True

    def load(self, w):
        if len(w)!=self.size+1:
            raise Exception("Incorrect shape of w: ", w.shape, " expected ", (self.size+1,))
        self.w = w
        self.is_fitted = True

    def predict(self, X):
        if not self.is_fitted:
            raise Exception("Try to predict from unfitted DerivativeLinearRegression")
        X_poly = self.poly.fit_transform(X.reshape(-1, 1))
        return np.dot(X_poly, self.w)

    def custom_loss(self, w, X_poly, y):
        y_pred = np.dot(X_poly, w)
        loss = np.mean((y - y_pred) ** 2) + self.alpha * np.sum(w * w)
        return loss

    def generate_derivative_constraint_function(self, derivative):
        def derivative_constraint(w):
            deriv = 0
            for i in range(len(w)):
                deriv += i * (derivative["point"] ** (i - 1.0)) * w[i]
            return deriv - derivative["value"]
        return derivative_constraint

    def generate_constant_constraint_function(self, constant):
        def constant_constraint(w):
            value = 0
            for i in range(len(w)):
                value += (constant["point"]**i) * w[i]
            return value - constant["value"]
        return constant_constraint


    def get_w(self):
        if not self.is_fitted:
            raise Exception("Try to get weights from unfitted DerivativeLinearRegression")
        return self.w


class IvyModel(PredictingModel):
    def init(self, size):
        self.is_init = True
        self.size = size
        self.poly = PolynomialFeatures(size=self.size)
        self.is_fitted = False

    def load(self, weights):
        self.start_r, self.end_r = weights[0], weights[1]
        self.w = weights[2:]
        self.is_fitted = True

    def fit(self, X, y, derivatives, consts, alpha=0.0001):
        if not self.is_init:
            raise Exception("DerivativeLinearRegression is not init")
        self.start_r, self.end_r = y[0], y[-1]
        new_y = y / ((self.end_r-self.start_r)*X+self.start_r)

        X_poly = self.poly.fit_transform(X.reshape(-1, 1))
        w_init = np.zeros(X_poly.shape[1])

        self.alpha = alpha
        constraints = []
        for derivative in derivatives:
            new_constraint = {'type': 'eq', 'fun': self.generate_derivative_constraint_function(derivative)}
            constraints.append(new_constraint)
        for const in consts:
            new_constraint = {'type': 'eq', 'fun': self.generate_constant_constraint_function(const)}
            constraints.append(new_constraint)

        res = minimize(self.custom_loss, w_init, args=(X_poly, new_y), constraints=constraints)
        self.w = res.x
        self.is_fitted = True

    def custom_loss(self, w, X_poly, y):
        y_pred = np.dot(X_poly, w)
        loss = np.mean(np.abs(y - y_pred)) + self.alpha * np.sum(w * w)
        #loss = np.mean((y - y_pred) ** 2) + self.alpha * np.sum(w * w)
        return loss

    def predict(self, X):
        if not self.is_fitted:
            raise Exception("Try to predict from unfitted IvyModel")
        X_poly = self.poly.fit_transform(X.reshape(-1, 1))
        inside_y = np.dot(X_poly, self.w)
        return inside_y * ((self.end_r-self.start_r)*X+self.start_r)

    def generate_derivative_constraint_function(self, derivative):
        def derivative_constraint(w):
            deriv = 0
            for i in range(len(w)):
                deriv += self.start_r*(i * (derivative["point"] ** (i - 1.0)) * w[i])
                deriv += (self.end_r-self.start_r)*((i+1.0)*(derivative["point"] ** i) * w[i])
            return deriv - derivative["value"]

        return derivative_constraint

    def generate_constant_constraint_function(self, constant):
        def constant_constraint(w):
            value = 0
            for i in range(len(w)):
                outside = (self.end_r-self.start_r)*constant["point"]+self.start_r
                value += (constant["point"] ** i) * w[i] * outside
            return value - constant["value"]

        return constant_constraint

    def mini_fit(self):
        #zero = self.predict([0])
        pass


    def get_w(self):
        if not self.is_fitted:
            raise Exception("Try to get weights from unfitted IvyModel")
        weights = [self.start_r, self.end_r] + list(self.w)
        return np.array(weights)


class UniformPredictModel(PredictingModel):

    def init(self, size):
        self.is_init = True
        self.size = size

    def fit(self, X, y, derivatives, consts):
        self.spline = interp1d(X, y)
        self.x_points = np.linspace(0, 1, self.size)
        self.w = self.spline(self.x_points)
        self.spline = interp1d(self.x_points, self.w)
        self.is_fitted = True

    def load(self, w):
        if len(w)!=self.size:
            raise Exception("Incorrect shape of w: ", w.shape, " expected ", (self.size,))
        self.w = w
        self.x_points = np.linspace(0, 1, self.size)
        self.spline = interp1d(self.x_points, self.w)
        self.is_fitted = True

    def predict(self, X):
        if not self.is_fitted:
            raise Exception("Try to predict from unfitted UniformPredictModel")
        return self.spline(X)

    def generate_derivative_constraint_function(self, derivative):
        raise Exception("In UniformPredictModel no constraints")

    def generate_constant_constraint_function(self, constant):
        raise Exception("In UniformPredictModel no constraints")

    def get_w(self):
        if not self.is_fitted:
            raise Exception("Try to get weights from unfitted UniformPredictModel")
        return self.w




