import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures


class PolyModel:
    def __init__(self):
        pass

    def init(self, poly_degree):
        self.poly_degree = poly_degree
        self.poly = PolynomialFeatures(degree=self.poly_degree)
        self.model = LinearRegression()

    def fit(self, X, y):
        X_poly = self.poly.fit_transform(X)
        self.model.fit(X_poly, y)

    def predict(self, X):
        if len(X.shape)==1:
            cx_poly = self.poly.fit_transform(X[np.newaxis, :])
            return self.model.predict(cx_poly)[0]
        else:
            cx_poly = self.poly.fit_transform(X)
            return self.model.predict(cx_poly)

    def loss(self, X, y):
        return float(np.sqrt(np.mean((y - self.predict(X)) ** 2)))

    def otn_loss(self, X, y):
        return float(np.sqrt(np.mean(((y - self.predict(X))/(0.5*y+self.predict(X)*0.5)) ** 2)))

    def get_data_to_save(self):

        data_to_save = {
            'coef': self.model.coef_,
            'intercept': self.model.intercept_,
            'degree': self.poly.degree,
            'include_bias': self.poly.include_bias,
            'interaction_only': self.poly.interaction_only,
            # если использовали нормализацию или другие параметры – тоже сохраните
        }
        return data_to_save


    def load(self, data_from_load):
        self.poly = PolynomialFeatures(
            degree=data_from_load['degree'],
            include_bias=data_from_load['include_bias'],
            interaction_only=data_from_load['interaction_only']
        )
        self.model = LinearRegression()
        self.model.coef_ = data_from_load['coef']
        self.model.intercept_ = data_from_load['intercept']
        self.model._is_fitted = True
