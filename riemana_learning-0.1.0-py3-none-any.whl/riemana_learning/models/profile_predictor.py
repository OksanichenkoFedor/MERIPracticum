from copy import deepcopy

import numpy as np
import pandas as pd
import os
import joblib
from matplotlib import pyplot as plt
from matplotlib.ticker import FuncFormatter
from tqdm import trange
from sklearn.model_selection import train_test_split

from riemana_learning.models.poly_model import PolyModel
from riemana_learning.pipelines.models import UniformPredictModel
from riemana_learning.pipelines.parametrization_converter import ParametrizationConverter
from riemana_learning.pipelines.poly_param_converter import PolyParametrizationConverter
from riemana_learning.pipelines.preprocessing_functions import get_profile_arrays, compare_poly_data, \
    give_cartesian_from_poly


class ProfilePredictor:
    def __init__(self):
        self.is_data_generated = False
        self.is_data_load = False
        self.is_fitted = False
        self.search_space = {
            "y_Ar": [0.1, 0.8],
            "y_Cl2": [0.05, 0.95],
            "W": [800, 1600],
            "bias": [50.0, 300.0]
        }

    def init(self, left, right, down):
        self.left, self.right, self.down = left, right, down

    def old_load_dataframe(self, folder_name, number):
        dataframes = os.listdir(folder_name)
        self.dataframes = []
        self.total_length = 0
        self.lengthes = []
        num_dataframes = min(number, len(dataframes))
        for i in trange(num_dataframes):
            dataframe = dataframes[i]
            new_df = pd.read_csv(folder_name+"/"+dataframe)
            self.total_length+=len(new_df)
            self.dataframes.append(new_df)
            self.lengthes.append(len(new_df))
        #print(self.lengthes)

        self.is_data_load = True

    def load_dataframe(self, folder_name, split_number):
        dataframes = os.listdir(folder_name)
        self.dataframes = []
        self.total_length = 0
        self.lengthes = []
        curr_dataframe, curr_len = None, 0
        for i in trange(len(dataframes)):
            if curr_dataframe is None:
                curr_dataframe = pd.read_hdf(folder_name + "/" + dataframes[i], key='df')
            else:
                new_dataframe = pd.read_hdf(folder_name + "/" + dataframes[i], key='df')
                curr_dataframe = pd.concat([curr_dataframe, new_dataframe], ignore_index=True)
                curr_len+=1
                if curr_len>=split_number:
                    self.total_length += len(curr_dataframe)
                    self.dataframes.append(curr_dataframe)
                    self.lengthes.append(len(curr_dataframe))
                    curr_dataframe, curr_len = None, 0
        self.total_length += len(curr_dataframe)
        self.dataframes.append(curr_dataframe)
        self.lengthes.append(len(curr_dataframe))
        #print(self.lengthes)

        self.is_data_load = True

    def load_model(self, filename: str) -> None:
        data_from_load = joblib.load(filename)

        self.model = PolyModel()
        self.model.load(data_from_load)
        self.control_parameters = data_from_load["control_parameters"]
        self.size_after_preprocessing = data_from_load["size_after_preprocessing"]
        self.left = data_from_load["left"]
        self.right = data_from_load["right"]
        self.down = data_from_load["down"]

    def save_model(self, filename: str):
        data_to_save = self.model.get_data_to_save()
        data_to_save["control_parameters"] = self.control_parameters
        data_to_save["size_after_preprocessing"] = self.size_after_preprocessing
        data_to_save["left"] = self.left
        data_to_save["right"] = self.right
        data_to_save["down"] = self.down

        joblib.dump(data_to_save, filename)

    def generate_dataset(self, size_after_preprocessing, control_parameters, time_th=0.0, x_filename=None, y_filename=None,
                         bound_part=0.5):
        do_processing = (x_filename is None) and (y_filename is None)
        if (not self.is_data_load) and do_processing:
            raise Exception("Try to generate dataset with empty data")
        self.bound_part = bound_part

        self.control_parameters = {element: idx for idx, element in enumerate(control_parameters)}
        self.size_after_preprocessing = size_after_preprocessing
        if do_processing:
            self.X = np.zeros((self.total_length, len(control_parameters)))
            self.Y = np.zeros((self.total_length, self.size_after_preprocessing * 2))
        else:
            self.X = np.load(x_filename)
            self.Y = np.load(y_filename)
        number_of_dataframe = 0
        ind_inside_dataframe = 0
        if do_processing:
            for i in trange(self.total_length):
                self.X[i] = self.prepare_x(number_of_dataframe, ind_inside_dataframe)
                self.Y[i] = self.prepare_poly(number_of_dataframe, ind_inside_dataframe, window_size=10,
                                              bound_part=bound_part)
                ind_inside_dataframe+=1
                if ind_inside_dataframe>=len(self.dataframes[number_of_dataframe]):
                    ind_inside_dataframe = 0
                    number_of_dataframe+=1

        self.time_tresh_hold(time_th)
        self.is_data_generated = True

    def prepare_x(self, number_of_dataframe, ind_inside_dataframe):
        control_vector = []
        for param in self.control_parameters:
            control_vector.append(self.dataframes[number_of_dataframe].loc[ind_inside_dataframe][param])
        return np.array(control_vector).astype(float)

    def prepare_poly(self, number_of_dataframe, ind_inside_dataframe, window_size, bound_part):
        X, Y = get_profile_arrays(self.dataframes[number_of_dataframe], ind_inside_dataframe)
        param_conv = ParametrizationConverter(self.left, self.right, self.down)
        model_x, model_y = UniformPredictModel(), UniformPredictModel()
        param_conv.load_cartesian(X, Y)
        param_conv.convert_from_cartesian_to_poly(window_size=window_size,
                                                  size_after_preprocessing=self.size_after_preprocessing,
                                                  model_x=model_x, model_y=model_y, bound_part=bound_part)
        return param_conv.get_poly_vector()

    def time_tresh_hold(self, time_th):
        self.time_th = time_th
        X_new = []
        Y_new = []
        self.times = set([])
        for i in range(len(self.X)):
            #print(self.control_parameters["time"], self.X[i, self.control_parameters["time"]])
            if self.X[i, self.control_parameters["time"]] > self.time_th:
                X_new.append(self.X[i])
                Y_new.append(self.Y[i])
                self.times.add(self.X[i, self.control_parameters["time"]])
        #print(self.times)
        self.num_times = len(self.times)
        self.X, self.Y = np.array(X_new), np.array(Y_new)

    def prepare(self, test_size=0.1, is_correct_time_divides=False):
        if is_correct_time_divides:
            if self.X.shape[0]%self.num_times!=0:
                raise Exception("Number of experiments do not divides to number of times")
            num_experiments = int(self.X.shape[0]//self.num_times)
            X_train, X_test, Y_train, Y_test = train_test_split(self.X.reshape((num_experiments, self.num_times, -1)),
                                                                self.Y.reshape((num_experiments, self.num_times, -1)),
                                                                test_size=test_size)
            #print(X_train.shape, Y_train.shape, Y_train.shape[0] * Y_train.shape[1])
            self.X_train = X_train.reshape((X_train.shape[0] * X_train.shape[1], self.X.shape[-1]))
            self.Y_train = Y_train.reshape((Y_train.shape[0] * Y_train.shape[1], self.Y.shape[-1]))
            self.X_test = X_test.reshape((X_test.shape[0] * X_test.shape[1], self.X.shape[-1]))
            self.Y_test = Y_test.reshape((Y_test.shape[0] * Y_test.shape[1], self.Y.shape[-1]))
            #print("train: ",self.X_train.shape, self.Y_train.shape)
            #print("test: ",self.X_test.shape, self.Y_test.shape)
        else:
            self.X_train, self.X_test, self.Y_train, self.Y_test = train_test_split(self.X, self.Y,
                                                                                    test_size=test_size)
        if not self.is_data_generated:
            raise Exception("Try to fit model without generated data")

    def fit(self, poly_degree):
        self.model = PolyModel()
        self.model.init(poly_degree)
        self.model.fit(self.X_train, self.Y_train)
        self.is_fitted = True

    def loss(self):
        if not self.is_fitted:
            raise Exception("Unfitted model doesn't have any loss")
        return self.model.loss(self.X_test, self.Y_test)

    def otn_loss(self):
        if not self.is_fitted:
            raise Exception("Unfitted model doesn't have any loss")
        return self.model.otn_loss(self.X_test, self.Y_test)

    def compare_data(self, num_x, num_y, verbose=0):
        #fig, axes = plt.subplots(num_y, num_x, figsize=(num_x * 4, num_y * 3))
        #fig, axes = plt.subplots(num_x, 3*num_y, figsize=(num_y * 6, num_x * 4))
        fig, axes = plt.subplots(num_x, num_y, figsize=(num_y * 2, num_x * 4))
        for x in range(num_x):
            for y in range(num_y):
                number_of_dataframe = np.random.randint(len(self.dataframes))
                curr_dataframe = self.dataframes[number_of_dataframe]
                number_in_dataframe = np.random.randint(len(curr_dataframe))
                while curr_dataframe.loc[number_in_dataframe]["time"] < self.time_th:
                    number_of_dataframe = np.random.randint(len(self.dataframes))
                    curr_dataframe = self.dataframes[number_of_dataframe]
                    number_in_dataframe = np.random.randint(len(curr_dataframe))
                if verbose>0:
                    print(number_of_dataframe, number_in_dataframe)
                curr_dict = curr_dataframe.loc[number_in_dataframe]
                curr_vector = np.array([curr_dict[key] for key in self.control_parameters if key in curr_dict])
                pred_poly = self.model.predict(curr_vector)
                #compare_poly_data((self.left, self.right, self.down), curr_dataframe, number_in_dataframe,
                #                  self.size_after_preprocessing, self.bound_part, pred_poly,
                #                  axes[x,3*y], axes[x,3*y+1], axes[x, 3*y+2])
                compare_poly_data((self.left, self.right, self.down), curr_dataframe, number_in_dataframe,
                                  self.size_after_preprocessing, self.bound_part, pred_poly,
                                  axes[x,y])
                # poly_vector = plot_profile_from_dataframe(df, num, axes[2*y,x], axes[2*y+1,x])
        plt.show()

    def get_search_space(self):
        return self.search_space

    def get_slide_params(self):
        params = {
            "y_Ar":(0.1, 0.8, 0.001),
            "y_Cl2":(0.05, 0.95, 0.001),
            "W":(800, 1600, 1),
            "bias":(50.0,300.0,1)
        }
        return params

    def give_xy_etch(self,**params):
        curr_vector = np.array([params[key] for key in self.control_parameters if key in params])
        for key in self.search_space:
            if self.search_space[key][0]>params[key] or self.search_space[key][1]<params[key]:
                raise Exception("Incorrect value of "+str(key)+" parameter ("+str(round(params[key],2))+
                                "). Should be in ["+str(round(self.search_space[key][0],2))+","+
                                str(round(self.search_space[key][1],2))+"]")
        #print(curr_vector)
        pred_poly = self.model.predict(curr_vector)
        poly_real_conv = PolyParametrizationConverter(self.left, self.right, self.down)
        model_x, model_y = UniformPredictModel(), UniformPredictModel()
        poly_real_conv.load_poly(pred_poly)
        poly_real_conv.convert_from_poly_to_cartesian(size_after_preprocessing=self.size_after_preprocessing,
                                                      model_x=model_x, model_y=model_y)
        x_etch, y_etch = poly_real_conv.get_x_etch(), poly_real_conv.get_y_etch()
        x_etch = np.abs(x_etch)
        return 2.5*x_etch, 2.5*y_etch

    def get_etching_rate(self, **params) -> float:
        params["time"] = 120

        delta_x, delta_y = self.give_xy_etch(**params)
        speed = delta_y / 2
        return float(speed)

    def get_anisotropy(self, **params) -> float:
        params["time"] = 120

        delta_x, delta_y = self.give_xy_etch(**params)
        anis = delta_y/delta_x
        return float(anis)

    def plot_slide(self, **control_params):
        control_params["time"] = 120
        curr_vector = np.array([control_params[key] for key in self.control_parameters if key in control_params])

        pred_poly = self.model.predict(curr_vector)
        plot_X, plot_y = give_cartesian_from_poly((self.left, self.right, self.down),
                                                  pred_poly, self.size_after_preprocessing)

        plt.figure(figsize=(6, 4))
        plt.plot(plot_X, plot_y)
        plt.xlim([0.5 * self.left + 0.5 * self.right - 150, 0.5 * self.left + 0.5 * self.right + 150])
        plt.ylim([self.down + 350, self.down])
        plt.gca().set_aspect('equal')

        xsize = 0.5 * self.left + 0.5 * self.right
        multiplier = 2.5
        ticks_step = 100 / multiplier

        mask_y_coordinate = self.down

        def shift_x(x):
            return (x + 0.5 - xsize) * multiplier

        def shift_y(y):
            return (y + 0.5 - mask_y_coordinate) * multiplier

        def form_shift_x(x, pos):
            shifted_value = shift_x(x)
            if shifted_value.is_integer():
                return f"{int(shifted_value)}"
            else:
                return f"{shifted_value:g}"

        def form_shift_y(y, pos):
            shifted_value = shift_y(y)
            if shifted_value.is_integer():
                return f"{int(shifted_value)}"
            else:
                return f"{shifted_value:g}"

        x_zero_position = xsize - 0.5
        y_zero_position = mask_y_coordinate - 0.5

        plt.gca().xaxis.set_major_formatter(FuncFormatter(form_shift_x))
        plt.gca().yaxis.set_major_formatter(FuncFormatter(form_shift_y))
        plt.gca().yaxis.set_ticks(y_zero_position + np.arange(0, self.down + 350 - y_zero_position, ticks_step))
        #
        xticks = x_zero_position + np.concatenate((np.flip(np.arange(0, xsize * (-1.0), -ticks_step)),
                                                   np.arange(ticks_step, xsize, ticks_step)), axis=0)
        # print(xticks)
        plt.gca().set_xticks(xticks)

        plt.grid(True)
        plt.show()


